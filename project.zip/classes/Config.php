<?php

    class Config {

        const DB_HOST = 'localhost';
        const DB_NAME = 'prodavnica';
        const DB_SOURCE = 'mysql:host=' . self::DB_HOST . ';dbname=' . self::DB_NAME . ';charset=utf8';
        const DB_USER = 'root';
        const DB_PASSWORD = '';

    }

?>