<section class="main-banner mb-5">
    <div class="container">
        <div class="banner-text">
            <h1>Limi School Blogger</h1>
            <p>It is our belief that in order to be most efficient it requires adaptive technology and software our customers can focus on their core business.</p>
        </div>
    </div>
</section>